#pragma once
#include <vector>
#include "Pizza.h"
using namespace std;

class Order
{
	vector<Pizza> p;
public:
	void AddOrder(ostream&, istream&);
	void printOrder(ostream&);
};