#include <iomanip>
#include "Order.h"

void Order::AddOrder(ostream& out, istream& in) {
	Pizza pizza;
	char answer;
	do {
		pizza.input();
		p.push_back(pizza);
		out << "another pizza? (y/n) ";
		in >> answer;
	} while (answer == 'y' || answer == 'Y');

	out << endl;
}

void Order::printOrder(ostream& out) {
	out << left << setw(15) << "Type"
		<< left << setw(10) << "Size"
		<< left << setw(12) << "Toppings"
		<< "Cost" << endl;

	for (unsigned int i = 0; i<p.size(); i++)
		p[i].outputDescription();

	out << endl << endl;
}
