
class Pizza
{
	int type;
	int size;
	int toppings;

public:
	Pizza();//constructor
	Pizza(int);
	Pizza(int,int);
	void outputDescription();
	double computePrice();
	void setType(int);
	void setSize(int);
	void setTopping(int);
	void setPizza(int,int,int);
	int getType();
	int getSize();
	int getTopping();
	void input();
};

