#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include "Order.h"

using namespace std;

const int sizeA = 10;

int main()
{
	vector<Order> o;
	int option, order;

	do {
		system("cls");
		cout << "1. Add Order" << endl;
		cout << "2. Cancel Order" << endl;
		cout << "3. Print Order" << endl;
		cout << "4. Print all orders" << endl;
		cout << "5. Exit" << endl;
		cout << "Enter your option ==> ";
		cin >> option;

		Order o1;
		switch (option)
		{
		case 1:
			o1.AddOrder(cout, cin);
			o.push_back(o1);
			break;
		case 2:
			cout << "enter the order number: ";
			cin >> order;
			o.erase(o.begin() + order - 1);
			break;
		case 3:
			cout << "enter the order number: ";
			cin >> order;
			if (order >= 0 && order < o.size())
				o[order].printOrder(cout);
			else
				cout << "order number " << order << " not found" << endl;
			break;
		case 4:
			for (int i = 0; i < o.size(); i++)
				o[i].printOrder(cout);
			break;
		default:
			break;
		}

		system("pause");
	} while (option != 5);


	return 0;
}

