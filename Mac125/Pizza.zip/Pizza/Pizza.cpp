#include "Pizza.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

Pizza::Pizza(){
	type = 0;
	size = 0;
	toppings = 0;
}

Pizza::Pizza(int t):type(t)
{
	size = 0;
	toppings = 0;
}

Pizza::Pizza(int t,int s) : type(t),size(s)
{
	toppings = 0;
}

void Pizza::outputDescription()
{
	string types[3] = {"Deep Dish", "Hand Tossed","Pan"};
	string sizes[3] = {"Small", "Medium", "Large"};


	cout << left << setw(15) << types[type - 1]
		 << left << setw(13) << sizes[size - 1]
		 << left << setw(7) << toppings;

	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);

	cout << right << setw(7) << computePrice() << endl;

}

double Pizza::computePrice() {
	const double price[3] = {10,14,17};

	return price[size-1]+(toppings*2);
}

void Pizza::setType(int type) {this->type = type;}
void Pizza::setSize(int s) {size=s;}
void Pizza::setTopping(int t) {toppings = t;}

int Pizza::getType() {return type;}
int Pizza::getSize() { return size; }
int Pizza::getTopping() { return toppings; }

void Pizza::setPizza(int t,int s,int tp) { 
	setType(t);
	setSize(s);
	setTopping(tp);
}

void Pizza::input()
{
	int n;

	cout << "1. Deep Dish" << endl;
	cout << "2. Hand Tossed" << endl;
	cout << "3. Pan" << endl;
	n = rand() % 3 + 1;
	cout << "Select type of pizza ==> " << n << endl;

	setType(n);

	cout << endl;

	cout << "1. Small" << endl;
	cout << "2. Medium" << endl;
	cout << "3. Large" << endl;
	n = rand() % 3 + 1;
	cout << "Select size of pizza ==> " << n << endl;

	setSize(n);

	cout << endl;

	n = rand() % 10;
	cout << "Enter number of toppings ==> " << n << endl;

	setTopping(n);

	cout << endl;

}
